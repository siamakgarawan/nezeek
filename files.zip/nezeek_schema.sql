-- ════════════════════════════════════════
-- NEZEEK — Supabase Schema
-- ════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- برای جستجوی متنی

-- ────────────────────────────────────────
-- 1. PROFILES (extends auth.users)
-- ────────────────────────────────────────
CREATE TABLE profiles (
  id            UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  full_name     TEXT,
  phone         TEXT UNIQUE,
  avatar_url    TEXT,
  wallet_balance NUMERIC(14,0) DEFAULT 0,  -- تومان (بدون اعشار)
  city          TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, phone)
  VALUES (NEW.id, NEW.phone);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ────────────────────────────────────────
-- 2. VEHICLES (گاراژ)
-- ────────────────────────────────────────
CREATE TABLE vehicles (
  id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id     UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  make        TEXT NOT NULL,              -- سازنده
  model       TEXT NOT NULL,             -- مدل
  year        TEXT,                      -- سال
  vin         TEXT,                      -- شماره شاسی
  color       TEXT,
  plate       TEXT,                      -- پلاک
  image_url   TEXT,
  notes       TEXT,
  is_primary  BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_vehicles_user ON vehicles(user_id);

-- ────────────────────────────────────────
-- 3. MAINTENANCE_LOGS (سوابق سرویس)
-- ────────────────────────────────────────
CREATE TABLE maintenance_logs (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  vehicle_id   UUID REFERENCES vehicles(id) ON DELETE CASCADE NOT NULL,
  title        TEXT NOT NULL,
  cost         NUMERIC(14,0),
  mileage      INTEGER,
  notes        TEXT,
  performed_at TIMESTAMPTZ DEFAULT NOW()
);

-- ────────────────────────────────────────
-- 4. SERVICE_PROVIDERS (تعمیرگاه/کارواش/پارکینگ/...)
-- ────────────────────────────────────────
CREATE TABLE service_providers (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name          TEXT NOT NULL,
  type          TEXT NOT NULL,  -- 'repair'|'carwash'|'parking'|'tow_truck'|'gas_station'
  address       TEXT,
  city          TEXT,
  phone         TEXT,
  rating        NUMERIC(3,2) DEFAULT 0,
  review_count  INTEGER DEFAULT 0,
  location      GEOGRAPHY(POINT, 4326),       -- PostGIS
  working_hours JSONB,
  -- مثال: {"sat": "08:00-20:00", "fri": "closed"}
  services      JSONB,
  -- مثال: [{"name":"روغن‌کاری","price":120000},...]
  images        TEXT[],
  is_active     BOOLEAN DEFAULT TRUE,
  is_verified   BOOLEAN DEFAULT FALSE,
  owner_id      UUID REFERENCES profiles(id),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_providers_type ON service_providers(type);
CREATE INDEX idx_providers_location ON service_providers USING GIST(location);
CREATE INDEX idx_providers_city ON service_providers(city);

-- تابع جستجوی نزدیک (رادیوس به کیلومتر)
CREATE OR REPLACE FUNCTION get_nearby_providers(
  lat FLOAT,
  lng FLOAT,
  radius_km FLOAT,
  provider_type TEXT DEFAULT NULL
)
RETURNS TABLE(
  id UUID, name TEXT, type TEXT, address TEXT, phone TEXT,
  rating NUMERIC, review_count INTEGER, distance_m FLOAT,
  working_hours JSONB, services JSONB, images TEXT[], is_active BOOLEAN
)
LANGUAGE sql STABLE AS $$
  SELECT
    id, name, type, address, phone,
    rating, review_count,
    ST_Distance(location::geometry, ST_MakePoint(lng, lat)::geometry) AS distance_m,
    working_hours, services, images, is_active
  FROM service_providers
  WHERE
    is_active = TRUE
    AND ST_DWithin(
      location::geometry,
      ST_MakePoint(lng, lat)::geometry,
      radius_km * 1000
    )
    AND (provider_type IS NULL OR type = provider_type)
  ORDER BY distance_m;
$$;

-- ────────────────────────────────────────
-- 5. REVIEWS (نظرات)
-- ────────────────────────────────────────
CREATE TABLE reviews (
  id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id     UUID REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES service_providers(id) ON DELETE CASCADE,
  rating      SMALLINT CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, provider_id)
);

-- آپدیت خودکار rating در service_providers
CREATE OR REPLACE FUNCTION update_provider_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE service_providers
  SET
    rating = (SELECT AVG(rating) FROM reviews WHERE provider_id = NEW.provider_id),
    review_count = (SELECT COUNT(*) FROM reviews WHERE provider_id = NEW.provider_id)
  WHERE id = NEW.provider_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_review_change
  AFTER INSERT OR UPDATE OR DELETE ON reviews
  FOR EACH ROW EXECUTE FUNCTION update_provider_rating();

-- ────────────────────────────────────────
-- 6. CAR_LISTINGS (آگهی خودرو)
-- ────────────────────────────────────────
CREATE TABLE car_listings (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id         UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  make            TEXT,
  model           TEXT,
  year_jalali     TEXT,
  year_gregorian  TEXT,
  mileage         INTEGER,
  price           NUMERIC(15,0),            -- تومان
  city            TEXT,
  description     TEXT,
  condition       TEXT,  -- 'new'|'used'|'crashed'
  engine_type     TEXT,  -- 'petrol'|'diesel'|'hybrid'|'electric'
  chassis_changed BOOLEAN DEFAULT FALSE,
  damaged_parts   TEXT[],
  color           TEXT,
  images          TEXT[],
  is_active       BOOLEAN DEFAULT TRUE,
  views           INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_listings_city ON car_listings(city);
CREATE INDEX idx_listings_make_model ON car_listings(make, model);
CREATE INDEX idx_listings_price ON car_listings(price);
CREATE INDEX idx_listings_search ON car_listings USING GIN(
  to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(make,'') || ' ' || coalesce(model,''))
);

-- ────────────────────────────────────────
-- 7. ORDERS (سفارش‌ها / رزروها)
-- ────────────────────────────────────────
CREATE TABLE orders (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id       UUID REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id   UUID REFERENCES service_providers(id),
  service_name  TEXT,
  status        TEXT DEFAULT 'pending',
  -- pending → confirmed → in_progress → done | cancelled
  scheduled_at  TIMESTAMPTZ,
  total_amount  NUMERIC(14,0),
  notes         TEXT,
  vehicle_id    UUID REFERENCES vehicles(id),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_provider ON orders(provider_id);
CREATE INDEX idx_orders_status ON orders(status);

-- ────────────────────────────────────────
-- 8. WALLET_TRANSACTIONS
-- ────────────────────────────────────────
CREATE TABLE wallet_transactions (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id      UUID REFERENCES profiles(id) ON DELETE CASCADE,
  amount       NUMERIC(14,0) NOT NULL,
  type         TEXT NOT NULL,  -- 'credit'|'debit'
  category     TEXT,
  -- 'charge'|'repair'|'carwash'|'parking'|'toll'|'purchase'
  order_id     UUID REFERENCES orders(id),
  reference    TEXT,          -- شماره پیگیری درگاه
  description  TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- آپدیت خودکار wallet_balance
CREATE OR REPLACE FUNCTION update_wallet_balance()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.type = 'credit' THEN
    UPDATE profiles SET wallet_balance = wallet_balance + NEW.amount WHERE id = NEW.user_id;
  ELSE
    UPDATE profiles SET wallet_balance = wallet_balance - NEW.amount WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_transaction
  AFTER INSERT ON wallet_transactions
  FOR EACH ROW EXECUTE FUNCTION update_wallet_balance();

-- ────────────────────────────────────────
-- 9. SAVED_SEARCHES
-- ────────────────────────────────────────
CREATE TABLE saved_searches (
  id         UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id    UUID REFERENCES profiles(id) ON DELETE CASCADE,
  query      TEXT,
  category   TEXT,
  filters    JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ────────────────────────────────────────
-- 10. BOOKMARKS
-- ────────────────────────────────────────
CREATE TABLE bookmarks (
  id         UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id    UUID REFERENCES profiles(id) ON DELETE CASCADE,
  listing_id UUID REFERENCES car_listings(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, listing_id)
);

-- ────────────────────────────────────────
-- 11. NOTIFICATIONS
-- ────────────────────────────────────────
CREATE TABLE notifications (
  id         UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id    UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title      TEXT,
  body       TEXT,
  type       TEXT,  -- 'order_update'|'promo'|'parking_alert'|'system'
  data       JSONB,
  is_read    BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ────────────────────────────────────────
-- 12. MAGAZINE_POSTS (مجله)
-- ────────────────────────────────────────
CREATE TABLE magazine_posts (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title        TEXT NOT NULL,
  content      TEXT,
  cover_image  TEXT,
  category     TEXT,  -- 'news'|'review'|'video'|'tech'|'guide'
  author       TEXT,
  views        INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT TRUE,
  published_at TIMESTAMPTZ DEFAULT NOW()
);

-- ────────────────────────────────────────
-- 13. EXPERTS (مشاوران)
-- ────────────────────────────────────────
CREATE TABLE experts (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id      UUID REFERENCES profiles(id),
  name         TEXT NOT NULL,
  specialty    TEXT[],  -- ['فنی','رنگ‌بدنه','بیمه']
  bio          TEXT,
  hourly_rate  NUMERIC(14,0),
  rating       NUMERIC(3,2) DEFAULT 0,
  review_count INTEGER DEFAULT 0,
  avatar_url   TEXT,
  is_available BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ────────────────────────────────────────
-- 14. AUTO_PARTS (فروشگاه لوازم)
-- ────────────────────────────────────────
CREATE TABLE auto_parts (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  seller_id    UUID REFERENCES profiles(id),
  title        TEXT NOT NULL,
  category     TEXT,
  brand        TEXT,
  price        NUMERIC(14,0),
  stock        INTEGER DEFAULT 0,
  description  TEXT,
  images       TEXT[],
  compatible   TEXT[],  -- ['پژو206','سمند']
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ────────────────────────────────────────
-- 15. PARKING_SPOTS (وضعیت جایگاه - Realtime)
-- ────────────────────────────────────────
CREATE TABLE parking_spots (
  id           UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  provider_id  UUID REFERENCES service_providers(id) ON DELETE CASCADE,
  spot_number  TEXT NOT NULL,
  floor        TEXT,
  is_occupied  BOOLEAN DEFAULT FALSE,
  occupied_by  UUID REFERENCES vehicles(id),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- ════════════════════════════════════════

ALTER TABLE profiles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_logs  ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews           ENABLE ROW LEVEL SECURITY;
ALTER TABLE car_listings      ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders            ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_searches    ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookmarks         ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications     ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_parts        ENABLE ROW LEVEL SECURITY;
ALTER TABLE parking_spots     ENABLE ROW LEVEL SECURITY;

-- PROFILES
CREATE POLICY "profiles: own read/write"
  ON profiles FOR ALL
  USING (auth.uid() = id);

-- VEHICLES
CREATE POLICY "vehicles: own CRUD"
  ON vehicles FOR ALL
  USING (auth.uid() = user_id);

-- MAINTENANCE LOGS
CREATE POLICY "maintenance: own vehicle logs"
  ON maintenance_logs FOR ALL
  USING (
    vehicle_id IN (SELECT id FROM vehicles WHERE user_id = auth.uid())
  );

-- SERVICE PROVIDERS: همه می‌تونن بخونن، فقط owner می‌تونه ویرایش کنه
CREATE POLICY "providers: public read"
  ON service_providers FOR SELECT
  USING (is_active = TRUE);

CREATE POLICY "providers: owner write"
  ON service_providers FOR ALL
  USING (auth.uid() = owner_id);

-- REVIEWS
CREATE POLICY "reviews: public read"
  ON reviews FOR SELECT USING (TRUE);

CREATE POLICY "reviews: own write"
  ON reviews FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- CAR LISTINGS
CREATE POLICY "listings: public read active"
  ON car_listings FOR SELECT
  USING (is_active = TRUE);

CREATE POLICY "listings: owner CRUD"
  ON car_listings FOR ALL
  USING (auth.uid() = user_id);

-- ORDERS
CREATE POLICY "orders: own"
  ON orders FOR ALL
  USING (auth.uid() = user_id);

-- WALLET
CREATE POLICY "wallet: own transactions"
  ON wallet_transactions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "wallet: insert own"
  ON wallet_transactions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- SAVED SEARCHES, BOOKMARKS, NOTIFICATIONS
CREATE POLICY "saved_searches: own" ON saved_searches FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "bookmarks: own" ON bookmarks FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "notifications: own" ON notifications FOR SELECT USING (auth.uid() = user_id);

-- AUTO PARTS
CREATE POLICY "parts: public read"
  ON auto_parts FOR SELECT USING (is_active = TRUE);
CREATE POLICY "parts: seller write"
  ON auto_parts FOR ALL USING (auth.uid() = seller_id);

-- PARKING SPOTS: Realtime-friendly
CREATE POLICY "parking_spots: public read"
  ON parking_spots FOR SELECT USING (TRUE);

-- ════════════════════════════════════════
-- REALTIME PUBLICATIONS
-- ════════════════════════════════════════
-- فعال‌سازی Realtime برای جداول مهم در Supabase Dashboard:
-- orders, parking_spots, notifications

-- ════════════════════════════════════════
-- STORAGE BUCKETS
-- ════════════════════════════════════════
-- در Supabase Dashboard بساز:
-- 1. "car-photos"    → public, max 10MB, image/*
-- 2. "avatars"       → public, max 2MB, image/*
-- 3. "shop-images"   → public, max 10MB, image/*

-- ════════════════════════════════════════
-- SEED DATA (نمونه برای تست)
-- ════════════════════════════════════════
INSERT INTO service_providers (name, type, address, city, phone, rating, review_count, location, working_hours, services, is_active, is_verified)
VALUES
  (
    'تعمیرگاه ستاره شرق',
    'repair',
    'تهران، خیابان آزادی، پلاک ۱۲',
    'تهران',
    '021-44001234',
    4.7,
    128,
    ST_MakePoint(51.338, 35.699),
    '{"sat":"08:00-19:00","sun":"08:00-19:00","mon":"08:00-19:00","tue":"08:00-19:00","wed":"08:00-19:00","thu":"08:00-14:00","fri":"closed"}',
    '[{"name":"تعویض روغن","price":150000},{"name":"تنظیم موتور","price":350000},{"name":"تعویض لنت","price":280000}]',
    TRUE,
    TRUE
  ),
  (
    'کارواش نانو پرو',
    'carwash',
    'تهران، سعادت‌آباد، میدان کاج',
    'تهران',
    '021-88901234',
    4.5,
    89,
    ST_MakePoint(51.360, 35.758),
    '{"sat":"07:00-21:00","sun":"07:00-21:00","mon":"07:00-21:00","tue":"07:00-21:00","wed":"07:00-21:00","thu":"07:00-21:00","fri":"09:00-18:00"}',
    '[{"name":"شستشوی سدان","price":85000},{"name":"شستشوی شاسی","price":115000},{"name":"واکس","price":250000}]',
    TRUE,
    TRUE
  ),
  (
    'پارکینگ مکانیزه مرکز',
    'parking',
    'تهران، انقلاب، نزدیک دانشگاه تهران',
    'تهران',
    '021-66700000',
    4.2,
    204,
    ST_MakePoint(51.394, 35.700),
    '{"sat":"00:00-23:59","sun":"00:00-23:59","mon":"00:00-23:59","tue":"00:00-23:59","wed":"00:00-23:59","thu":"00:00-23:59","fri":"00:00-23:59"}',
    '[{"name":"۱ ساعت","price":15000},{"name":"۳ ساعت","price":35000},{"name":"شبانه‌روز","price":120000}]',
    TRUE,
    TRUE
  );
