# NEZEEK — معماری Flutter + Supabase

## تحلیل پروتوتایپ AI Studio

| ویژگی | تعداد |
|---|---|
| صفحات شناسایی‌شده | 36 screen |
| دسته‌بندی سرویس | 12 category |
| جداول SQLite (پروتوتایپ) | 9 table |
| جداول Supabase (هدف) | 15+ table |

### دسته‌بندی‌های سرویس (12 مورد)
درخواست خودرو · آگهی خودرو · تعمیرگاه · فروشگاه لوازم · کارواش · پمپ بنزین · پارکینگ · امداد خودرو · مجله خودرو · عوارض و خلافی · مشاوره · باربری

---

## Flutter Project Structure (Feature-based Clean Architecture)

```
lib/
├── main.dart
├── core/
│   ├── constants/
│   │   ├── app_constants.dart
│   │   ├── route_constants.dart        # نام روت‌ها
│   │   └── supabase_constants.dart     # table/bucket names
│   ├── theme/
│   │   ├── app_theme.dart              # ThemeData RTL-aware
│   │   └── app_colors.dart             # palette (پالت بنفش پروتوتایپ)
│   ├── utils/
│   │   ├── jalali_utils.dart           # تاریخ شمسی با shamsi_date
│   │   ├── persian_digits.dart         # ۱۲۳ ↔ 123
│   │   ├── location_utils.dart         # DistanceCalculator
│   │   └── currency_utils.dart         # فرمت تومان
│   ├── providers/
│   │   └── supabase_provider.dart      # global SupabaseClient provider
│   └── router/
│       └── app_router.dart             # GoRouter + redirect logic
│
├── features/
│   │
│   ├── auth/
│   │   ├── data/
│   │   │   ├── auth_repository_impl.dart
│   │   │   └── supabase_auth_source.dart
│   │   ├── domain/
│   │   │   ├── auth_repository.dart
│   │   │   └── use_cases/
│   │   │       ├── send_otp_use_case.dart
│   │   │       └── verify_otp_use_case.dart
│   │   └── presentation/
│   │       ├── screens/
│   │       │   ├── phone_screen.dart
│   │       │   └── otp_screen.dart
│   │       └── providers/
│   │           └── auth_notifier.dart
│   │
│   ├── home/
│   │   └── presentation/
│   │       ├── home_screen.dart        # گرید 12 سرویس
│   │       └── widgets/
│   │           ├── category_card.dart
│   │           ├── featured_ads_carousel.dart
│   │           └── search_island.dart
│   │
│   ├── repair_shops/                   # MVP اول
│   │   ├── data/
│   │   │   ├── repair_shop_repo_impl.dart
│   │   │   └── sources/
│   │   │       └── supabase_repair_source.dart
│   │   ├── domain/
│   │   │   ├── models/repair_shop.dart
│   │   │   ├── repair_shop_repository.dart
│   │   │   └── use_cases/
│   │   │       ├── get_nearby_shops.dart
│   │   │       └── book_repair_slot.dart
│   │   └── presentation/
│   │       ├── screens/
│   │       │   ├── repair_shops_list_screen.dart
│   │       │   └── repair_shop_detail_screen.dart
│   │       └── providers/
│   │           └── repair_shops_provider.dart
│   │
│   ├── carwash/           # ساختار مشابه repair_shops
│   ├── parking/           # ساختار مشابه + Realtime برای جای خالی
│   ├── tow_truck/         # امداد خودرو
│   ├── buy_sell/          # آگهی خودرو
│   ├── auto_parts/        # فروشگاه لوازم
│   ├── gas_station/       # پمپ بنزین
│   ├── taxi/              # درخواست خودرو / carpool
│   ├── magazine/          # مجله
│   ├── tolls/             # عوارض و خلافی
│   ├── consulting/        # مشاوره
│   ├── moving/            # باربری
│   │
│   ├── garage/            # گاراژ من
│   │   ├── domain/
│   │   │   └── models/
│   │   │       ├── vehicle.dart
│   │   │       └── maintenance_log.dart
│   │   └── presentation/
│   │       ├── garage_screen.dart
│   │       ├── add_vehicle_screen.dart
│   │       └── maintenance_log_screen.dart
│   │
│   ├── profile/
│   │   └── presentation/
│   │       ├── profile_screen.dart
│   │       ├── edit_profile_screen.dart
│   │       ├── settings_screen.dart
│   │       └── support_screen.dart
│   │
│   ├── wallet/
│   │   └── presentation/
│   │       ├── wallet_screen.dart
│   │       └── transactions_screen.dart
│   │
│   ├── orders/
│   │   └── presentation/
│   │       ├── orders_list_screen.dart
│   │       └── order_tracking_screen.dart  # Realtime
│   │
│   └── nezeek_yar/        # دستیار هوش مصنوعی
│       ├── data/
│       │   └── gemini_source.dart         # Edge Function proxy
│       └── presentation/
│           ├── nezeek_yar_screen.dart
│           └── nezeek_yar_chat.dart
│
└── shared/
    ├── widgets/
    │   ├── persian_app_bar.dart        # AppBar با فونت فارسی
    │   ├── service_card.dart           # کارت تعمیرگاه/کارواش/...
    │   ├── rating_bar_widget.dart
    │   ├── map_preview_widget.dart
    │   ├── bottom_nav_bar.dart         # ناوبار پایین (5 آیتم)
    │   ├── loading_shimmer.dart
    │   └── error_view.dart
    ├── models/
    │   └── service_provider_base.dart  # base class مشترک
    └── services/
        ├── location_service.dart       # geolocator
        └── notification_service.dart   # FCM + local
```

---

## pubspec.yaml — Dependencies

```yaml
name: nezeek
description: پلتفرم جامع خدمات خودرو

environment:
  sdk: ">=3.2.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter

  # ── Backend ──────────────────────────────
  supabase_flutter: ^2.5.0

  # ── State & Navigation ───────────────────
  flutter_riverpod: ^2.5.1
  riverpod_annotation: ^2.3.5
  go_router: ^13.2.0

  # ── AI ───────────────────────────────────
  google_generative_ai: ^0.4.6

  # ── Maps ─────────────────────────────────
  google_maps_flutter: ^2.7.0
  geolocator: ^12.0.0
  geocoding: ^3.0.0

  # ── Persian / Jalali ─────────────────────
  shamsi_date: ^1.4.1
  persian_datetime_picker: ^3.2.1

  # ── Local Cache ───────────────────────────
  drift: ^2.18.0
  sqlite3_flutter_libs: ^0.5.0

  # ── HTTP ─────────────────────────────────
  dio: ^5.4.3+1

  # ── Notifications ────────────────────────
  flutter_local_notifications: ^17.2.1+2
  firebase_messaging: ^15.0.3

  # ── Images ───────────────────────────────
  cached_network_image: ^3.3.1
  image_picker: ^1.1.2

  # ── UI ───────────────────────────────────
  flutter_svg: ^2.0.10+1
  lucide_icons: ^0.0.1           # یا icons دیگر
  shimmer: ^3.0.0

  # ── Utils ────────────────────────────────
  intl: ^0.19.0
  url_launcher: ^6.3.0
  share_plus: ^10.0.0
  qr_code_scanner: ^1.0.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  riverpod_generator: ^2.4.0
  build_runner: ^2.4.9
  flutter_lints: ^4.0.0
```

---

## main.dart — راه‌اندازی

```dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL'),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY'),
  );

  runApp(
    const ProviderScope(
      child: NezeekApp(),
    ),
  );
}

class NezeekApp extends ConsumerWidget {
  const NezeekApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    return MaterialApp.router(
      title: 'نزیک',
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      routerConfig: router,
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
    );
  }
}
```

---

## الگوی استاندارد هر Feature

هر feature از این ۴ لایه تشکیل می‌شه:

```dart
// 1. Entity (domain/models)
class RepairShop {
  final String id;
  final String name;
  final RepairShopType type;
  final double rating;
  final LatLng location;
  // ...
}

// 2. Repository Interface (domain)
abstract class RepairShopRepository {
  Future<List<RepairShop>> getNearbyShops(LatLng center, double radiusKm);
  Future<RepairShop> getShopById(String id);
  Future<String> createBooking(BookingRequest request);
}

// 3. Implementation (data)
class SupabaseRepairShopRepository implements RepairShopRepository {
  final SupabaseClient _client;
  
  @override
  Future<List<RepairShop>> getNearbyShops(LatLng center, double radiusKm) async {
    final response = await _client.rpc('get_nearby_providers', params: {
      'lat': center.latitude,
      'lng': center.longitude,
      'radius_km': radiusKm,
      'provider_type': 'repair',
    });
    return (response as List).map((e) => RepairShop.fromJson(e)).toList();
  }
}

// 4. Riverpod Provider (presentation)
@riverpod
Future<List<RepairShop>> nearbyRepairShops(
  NearbyRepairShopsRef ref,
  LatLng location,
) async {
  final repo = ref.read(repairShopRepositoryProvider);
  return repo.getNearbyShops(location, 5.0);
}
```

---

## Roadmap (اولویت‌بندی)

### Phase 1 — MVP (4–5 هفته)
- [x] راه‌اندازی Flutter + Supabase
- [ ] Auth: ورود با OTP موبایل
- [ ] Profile + گاراژ (افزودن خودرو)
- [ ] Home screen (گرید 12 سرویس)
- [ ] **تعمیرگاه**: لیست → جزئیات → رزرو
- [ ] **کارواش**: لیست → جزئیات → رزرو
- [ ] **پارکینگ**: لیست → جزئیات → رزرو + Realtime
- [ ] **امداد خودرو**: درخواست + ردیابی
- [ ] سرویس‌های Supabase پیاده‌سازی‌شده

### Phase 2 — تجارت (4 هفته)
- [ ] آگهی خودرو: مرور + ثبت + جزئیات + بوکمارک
- [ ] فروشگاه لوازم: مرور + سبد خرید + سفارش
- [ ] کیف پول + تراکنش‌ها
- [ ] ردیابی سفارش‌ها (Realtime)
- [ ] نوتیفیکیشن Push (FCM)

### Phase 3 — AI + محتوا (4 هفته)
- [ ] **نزیک‌یار** (Gemini AI از طریق Edge Function)
- [ ] عوارض و خلافی (استعلام با پلاک)
- [ ] مجله خودرو (مقاله + ویدیو)
- [ ] مشاوره (مرور متخصص + رزرو)
- [ ] باربری + درخواست خودرو

### Phase 4 — Scaling
- [ ] نظرات و امتیازدهی
- [ ] جستجوی پیشرفته + فیلتر
- [ ] داشبورد کسب‌وکارها
- [ ] Analytics
